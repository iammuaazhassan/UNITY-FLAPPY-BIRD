using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LogicScript : MonoBehaviour
{
    public int playerScore;
    public Text scoreText;
    public GameObject gameOverScreen;

    void Update()
    {
        // Check if the game is over and the "Enter" key is pressed
        if (Input.GetKeyDown(KeyCode.Return))
            {
                restartGame();
            }
        else if(gameOverScreen.activeSelf )
        {
            if (Input.GetKeyDown(KeyCode.Return))
            {
                restartGame();
            }
            else if (Input.GetKeyDown(KeyCode.Escape))
            {
                ExitGame();
            }
        }
    }

    [ContextMenu("Increse Score")]
    public void addScore(int scoreToAdd)
    {
        playerScore = playerScore + scoreToAdd;
        scoreText.text = playerScore.ToString();
    }
    public void restartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void gameOver()
    {
        Debug.Log("Game Over!");
        gameOverScreen.SetActive(true);
    }
    public void ExitGame()
    {
        Debug.Log("Quitting Game...");
        Application.Quit();
    }
}

